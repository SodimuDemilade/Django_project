from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import authentication, permissions
from django.contrib.auth.models import User
from .models import (CEC_Course, CEC_NewCourse, CEC_TopCourse, CEC_FeaturedCourse)
from .serializer import CEC_CourseSerializer
from django.http import HttpResponse, JsonResponse
from rest_framework.parsers import JSONParser
from django.shortcuts import get_object_or_404, get_list_or_404
from django.views.decorators.csrf import csrf_exempt
from rest_framework.generics import RetrieveUpdateAPIView
import json


class coursedetail(APIView):
    def get(self, request, new, top, featured, learning_style, price, institution_id, search_text):
        queryset = CEC_Course.objects.all()
        if new == "Y":
            queryset = queryset.filter(cec_topcourse__is_removed="False")
            if top == "Y":
                queryset = queryset.filter(cec_newcourse__is_removed="False")
            if featured == "Y":
                queryset = queryset.filter(cec_featuredcourse__is_removed="False")
        elif top == "Y":
            queryset = CEC_Course.objects.filter(cec_newcourse__is_removed="False")
            if featured == "Y":
                queryset = queryset.filter(cec_featuredcourse__is_removed="False")
        elif featured == "Y":
            queryset = CEC_Course.objects.filter(cec_featuredcourse__is_removed="False")
        # BASED ON FIELDS IN THE COURSE TABLE
        if learning_style != " ":
            queryset = queryset.filter(learning_style=learning_style)
            if price != " ":
                queryset = queryset.filter(price=price)
            if institution_id != " ":
                queryset = queryset.filter(institution_id=institution_id)
        elif price != " ":
            queryset = queryset.objects.filter(price=price)
            if institution_id != " ":
                queryset = queryset.filter(institution_id=institution_id)
        elif institution_id != " ":
            queryset = queryset.objects.filter(institution_id=institution_id)
        serializer = CEC_CourseSerializer(queryset, many=True)

        return JsonResponse(serializer.data, safe=False)
